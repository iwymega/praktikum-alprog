#include <iostream>
#include <stdlib.h>
#include <math.h>
using namespace std;

const float PI = 3.14; // Nilai Phi


//Volume Bangun Ruang
void HitungVolumeBalok(float a, );
/*
 p = panjang
 l = lebar
 t = tinggi
*/

void HitungVolumeBola();
/*
 r = jari-jari
*/

void HitungVolumeLimas();
/*
 Limas segitiga sama sisi
 s = sisi alas segitiga
 t = tinggi
*/

void HitungVolumePrisma();
/*
 Prisma segitiga sama sisi
 s = sisi segitiga
 t = tinggi
*/

void HitungVolumeTabung();
/*
 r = jari-jari
 t = tinggi
*/


//Luas Permukaan Bangun Ruang

void HitungLuasBalok();
/*
 p = panjang
 l = lebar
 t = tinggi
*/

void HitungLuasBola();
/*
 r = jari=jari
*/

void HitungLuasLimas();
/*
 
*/

void HitungLuasPrisma();
/*
 
*/

void HitungLuasTabung();
/*
 
*/

void menu();

int main(){

       menu();
       return 0;
}






